package com.example.timecontrol;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;


public class MainActivity extends Activity {

    static  int count=0;
    private ScreenListener screenlistener;
    static int hour=100,min=100,hour2=0,min2=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


        hour=100;
        min=100;
        final MediaPlayer mediaPlayer=MediaPlayer.create(this,R.raw.pam);

        Toast.makeText(MainActivity.this,"转动轮盘，选择您希望在关闭屏幕多久后提醒",Toast.LENGTH_SHORT).show();


        final TimePicker timePicker=findViewById(R.id.time);
        timePicker.setHour(0);
        timePicker.setMinute(0);
        timePicker.setIs24HourView(true);

        screenlistener=new ScreenListener(this);

        Button but_cancel=findViewById(R.id.cancel);
        but_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,alarm_clock.class);
                PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0, intent , 0);
                AlarmManager alarm=(AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarm.cancel(pi);
                Toast.makeText(MainActivity.this,"您已取消闹钟",Toast.LENGTH_SHORT).show();
            }
        });


        Button button1=findViewById(R.id.set);
        button1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                hour=timePicker.getHour();
                min=timePicker.getMinute();
                count=0;
            screenlistener.begin(new ScreenListener.ScreenStateListener() {
            @Override
            public void onScreenOn() {
                Intent intent=new Intent(MainActivity.this,alarm_clock.class);
                PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0, intent , 0);
                AlarmManager alarm=(AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarm.cancel(pi);
                Toast.makeText(MainActivity.this,"您已设置时间将在"+hour+"分钟"+min+"秒后提醒",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onScreenOff() {
                Intent intent=new Intent(MainActivity.this,alarm_clock.class);
                PendingIntent pendingIntent=PendingIntent.getActivity(MainActivity.this,0,intent,0);
                AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+hour*60*1000+min*1000,pendingIntent);

            }

            @Override
            public void onUsePresent() {
            }
        });

            }
        });
    }
}


