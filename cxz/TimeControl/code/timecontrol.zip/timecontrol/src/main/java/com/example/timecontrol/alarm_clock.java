package com.example.timecontrol;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.support.annotation.MainThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class alarm_clock extends AppCompatActivity {


    private  Context context;
    private  ScreenListener screenlistener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_clock);

        final MediaPlayer mediaPlayer=MediaPlayer.create(this,R.raw.pam);





        mediaPlayer.start();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);



        final Button alarm_clock=findViewById(R.id.alarm_clock);
        alarm_clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.pause();
                Intent intent=new Intent(alarm_clock.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
